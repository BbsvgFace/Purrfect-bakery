const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');

let win;

function createWindow() {
  win = new BrowserWindow({
    width: 600,
    height: 840,
    minWidth: 430,
    minHeight: 620,
    alwaysOnTop: true,               // ← opens pinned above every window
    autoHideMenuBar: true,
    backgroundColor: '#2e1d12',
    title: 'Purrfect Bakery',
    icon: path.join(__dirname, 'build', 'icon.png'), // taskbar/window icon (dev + Linux/macOS runtime)
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  // 'floating' level keeps it above normal windows but under OS-critical UI
  win.setAlwaysOnTop(true, 'floating');
  win.loadFile('index.html');
}

// In-game 📌 button toggles the real OS always-on-top flag
ipcMain.handle('toggle-pin', () => {
  const next = !win.isAlwaysOnTop();
  win.setAlwaysOnTop(next, 'floating');
  return next;
});
ipcMain.handle('get-pin', () => win.isAlwaysOnTop());

app.whenReady().then(() => {
  if (process.platform === 'darwin' && app.dock) {
    app.dock.setIcon(path.join(__dirname, 'build', 'icon.png')); // dev-mode Dock icon (packaged .app uses build/icon.png → .icns automatically)
  }
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
