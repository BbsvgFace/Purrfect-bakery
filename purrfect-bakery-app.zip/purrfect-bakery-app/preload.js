const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('desktop', {
  togglePin: () => ipcRenderer.invoke('toggle-pin'),
  getPin: () => ipcRenderer.invoke('get-pin'),
});
