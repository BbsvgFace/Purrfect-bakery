# 🐾 Purrfect Bakery — Desktop App

A cozy pixel idle bakery + Pomodoro productivity game. Opens **pinned above every
window** on your desktop; the in-game 📌 button toggles it.

## Run it (2 minutes)

Requires [Node.js](https://nodejs.org) (LTS is fine).

```bash
npm install
npm start
```

The window opens already pinned on top. Click **📌 PINNED** in the title bar to unpin.

## Build a real executable

```bash
npm run dist
```

Output lands in `dist/`:

| Built on | You get |
|---|---|
| Windows | `Purrfect Bakery Setup 1.0.0.exe` (one-click installer) |
| macOS   | `Purrfect Bakery-1.0.0.dmg` |
| Linux   | `Purrfect Bakery-1.0.0.AppImage` |

Build on the OS you want the executable for — that's the reliable path
(cross-building Windows from Linux/macOS needs Wine and isn't worth the hassle).

## How the pin works

`main.js` creates the window with `alwaysOnTop: true` at the `'floating'` level,
and the game's 📌 button calls `win.setAlwaysOnTop(...)` over IPC
(`preload.js` exposes `window.desktop.togglePin()`). That's a true OS-level
always-on-top flag — it floats over browsers, editors, everything.

## Changing the app icon

The project ships with a placeholder pixel-art cat icon at `build/icon.ico`
(and `build/icon.png`). To use your own:

1. **Get a PNG.** [Flaticon](https://flaticon.com) is a good source — search
   something like "cupcake" or "chef cat," download the largest PNG size
   available. Free downloads usually require attribution; check the license
   on the download page (Flaticon Premium removes that requirement).
2. **Convert it to `.ico`.** Windows executables need `.ico`, not `.png`.
   Use a free converter like [icoconvert.com](https://icoconvert.com) —
   upload your PNG, select multiple sizes (16/32/48/256), download the result.
3. **Replace the file.** Drop the new file in as
   `build/icon.ico` (overwrite the placeholder), and also save a plain
   256×256 PNG version as `build/icon.png` (used for the in-app window icon
   and for Mac/Linux builds).
4. **Rebuild:**
   ```bash
   npm run dist
   ```
   The new icon shows on the installer, the Start Menu shortcut, and the
   taskbar. Running `npm start` (dev mode) also picks up `build/icon.png`
   for the window icon.

Note: a proper macOS build technically wants a `.icns` file rather than
`.png` for best results — only relevant if you ever build on a Mac.


- `index.html` — the entire game (scene, engine, screens, saves via localStorage)
- `main.js` — Electron window + pin IPC
- `preload.js` — safe bridge between game and Electron

## Tips

- **Demo 10s** focus length lets you test a full bake → break → stars loop in under a minute.
- Saves are automatic (localStorage) and survive restarts — including bakes in
  progress and idle chocolates earned while the app was closed.
